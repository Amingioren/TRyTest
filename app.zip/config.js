PORT = 3000;
IO_PORT = 4000;
DB_URI = "mongodb://136.243.225.5:27017/appoty";
HASH_KEY = "Amin1234@@"
BASE_URL = `http://136.243.225.5:${PORT}/`;
IO_URL = `http://136.243.225.5:${IO_PORT}`;